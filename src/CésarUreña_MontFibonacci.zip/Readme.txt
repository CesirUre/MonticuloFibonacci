La entrega contiene los siguientes archivos y documentos:
	- El PDF 'MontFibonacci_CésarUreña' que es la memoria con la discusión de los casos de prueba realizados y el análisis del coste.
	- La imagen 'GraficaTiempos' que es la gráfica generada para medir los tiempos.
	- El archivo Main.java que contiene la ejecución de los casos de prueba comentados en la memoria.
	- El archivo MainTime.java que es el que genera el archivo de texto para introducir en gnuplot y realizar la gráfica de tiempos.
	- El archivo MontículoFib que es donde estan implementado el montículo con todas sus operaciones.
	- El archivo Nodo que es la implementación de los nodos utilizados en MonticuloFib.java
	- El archivo FibonacciOutput.txt es el archivo para realizar la gráfica en gnuplot.